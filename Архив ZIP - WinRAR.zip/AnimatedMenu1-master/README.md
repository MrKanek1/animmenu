# Animated Menu WPF Application

# Implementation
https://www.youtube.com/watch?v=yrnE2Aah4B4
